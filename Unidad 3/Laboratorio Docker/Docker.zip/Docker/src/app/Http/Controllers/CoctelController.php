<?php

namespace App\Http\Controllers;

use App\Coctel;
use Illuminate\Http\Request;

class CoctelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cocktails = Coctel::all();
        return response()->json(['cocteles'=>$cocktails]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $coctel = new Coctel();
        $coctel->name_cocktail = $request['name_cocktail'];
        $coctel->alcoholic_base = $request['alcoholic_base'];
        $coctel->ingredients = $request['ingredients'];
        $coctel->recipe = $request['recipe'];
        $coctel->user = $request['user'];
        $coctel->save();
        return  $coctel;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //METODO 1
        $coctel = Coctel::where('id',$request['idCoctel'])->first();
        $coctel->name_cocktail = $request['name_cocktail'];
        $coctel->alcoholic_base = $request['alcoholic_base'];
        $coctel->ingredients = $request['ingredients'];
        $coctel->recipe = $request['recipe'];
        $coctel->user = $request['user'];
        $coctel->save();
        //METODO 2
        //$user = User::where('id',$request['idUser'])->update(['name'=>$request['name'],'password'=>$request['password'],'email'=>$request['email'],'type_user'=>$request['type_user']]);
        return $coctel;
    }

    public function delete(Request $request)
    {
        $coctel = Coctel::find($request['idCoctel']);
        $coctel->delete();
        return $coctel;
    }
}
