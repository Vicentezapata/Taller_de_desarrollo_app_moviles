<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Coctel extends Model
{
    public $table = "cocteles";
    /*public function ingredients(){
        return $this->hasMany('App\Ingredient','id','id_ingredients');
    }*/
}
