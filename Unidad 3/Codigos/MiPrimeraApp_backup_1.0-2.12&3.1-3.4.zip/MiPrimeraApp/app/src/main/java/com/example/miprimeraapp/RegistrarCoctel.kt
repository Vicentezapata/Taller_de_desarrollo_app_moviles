package com.example.miprimeraapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.launch
import roomDatabase.Db
import roomDatabase.entity.Cocktail

class RegistrarCoctel : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar_coctel)
        //REFERENCIAS
        val til_reg_name_cocktail = findViewById<TextInputLayout>(R.id.til_reg_name_cocktail)
        val til_reg_ingredients = findViewById<TextInputLayout>(R.id.til_reg_ingredients)
        val til_reg_recipe = findViewById<TextInputLayout>(R.id.til_reg_recipe)
        val sp_reg_alcohol = findViewById<Spinner>(R.id.sp_reg_alcohol)
        val btn_save = findViewById<Button>(R.id.btn_save)

        //OBTENEMOS EL VALOR DEL INTENT
        val mail:String = intent.getStringExtra("mail").toString()

        //INICIALIZAMOS LA DB
        val room = Room.databaseBuilder(this, Db::class.java,"database-ciisa.db").allowMainThreadQueries().build()

        //GENERACION DE SPINNER
        val arrayAdapterSpinner: ArrayAdapter<*>
        val alcohol = arrayOf("Ron","Pisco","Tequila","Vodka")
        arrayAdapterSpinner = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,alcohol)
        sp_reg_alcohol.adapter = arrayAdapterSpinner

        btn_save.setOnClickListener {
            if (validarCampos()==0){
                var name_cocktail = til_reg_name_cocktail.editText?.text.toString()
                var ingredients = til_reg_ingredients.editText?.text.toString()
                var recipe = til_reg_recipe.editText?.text.toString()
                var alcoholic_base = sp_reg_alcohol.selectedItem.toString()
                var id:Long = 0
                //CREAMOS EL OBJETO
                val cocktail = Cocktail(name_cocktail,alcoholic_base,ingredients,recipe,mail)
                //INSERTAMOS LA INFORMACION
                lifecycleScope.launch{
                    id = room.daoCocktail().agregarCocktail(cocktail)
                    if(id>0){
                        Log.d("IDcocktail",id.toString())

                        //LISTAR ELEMENTOS AÑADIDOS POR EL USUARIO mail (OPCIONAL)
                        val response = room.daoCocktail().obtenerCoctelesUsuario(mail)
                        for(r in response){
                            println(r.toString())
                        }

                        Toast.makeText(this@RegistrarCoctel,"Coctel registrado exitosamente", Toast.LENGTH_LONG)
                        val intent = Intent(this@RegistrarCoctel,DashboardUser::class.java)
                        intent.putExtra("mail",mail)
                        startActivity(intent)
                    }
                }

            }
        }



    }

    fun validarCampos():Int{
        val til_reg_name_cocktail = findViewById<TextInputLayout>(R.id.til_reg_name_cocktail)
        val til_reg_ingredients = findViewById<TextInputLayout>(R.id.til_reg_ingredients)
        val til_reg_recipe = findViewById<TextInputLayout>(R.id.til_reg_recipe)
        var contador:Int = 0
        var name_cocktail = til_reg_name_cocktail.editText?.text.toString()
        var ingredients = til_reg_ingredients.editText?.text.toString()
        var recipe = til_reg_recipe.editText?.text.toString()
        val validate = Validate()
        if(validate.validarCampoNulo(name_cocktail)){
            til_reg_name_cocktail.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            til_reg_name_cocktail.error = ""
        }
        if(validate.validarCampoNulo(ingredients)){
            til_reg_ingredients.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            til_reg_ingredients.error = ""
        }
        if(validate.validarCampoNulo(recipe)){
            til_reg_recipe.error = getString(R.string.error_null_field)
            contador++
        }
        return contador
    }
}