package roomDatabase.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Cocktail {
    @PrimaryKey(autoGenerate = true)
    var id:Long=0
    var name_cocktail:  String? = null
    var alcoholic_base: String? = null
    var ingredients: String? = null
    var recipe: String? = null
    var user: String? = null

    constructor(
        name_cocktail: String?,
        alcoholic_base: String?,
        ingredients: String?,
        recipe: String?,
        user: String?
    ) {
        this.name_cocktail = name_cocktail
        this.alcoholic_base = alcoholic_base
        this.ingredients = ingredients
        this.recipe = recipe
        this.user = user
    }

    override fun toString(): String {
        return "Cocktail(id=$id, name_cocktail=$name_cocktail, alcoholic_base=$alcoholic_base, ingredients=$ingredients, recipe=$recipe, user=$user)"
    }

}