package com.example.miprimeraapp

import android.util.Patterns
import java.util.regex.Pattern

class Validate {
    /**
     * FUNCION PARA VALIDAR SI EL TEXTO ES NULO
     * */
    fun validarCampoNulo(texto:String):Boolean{
        return texto.trim().equals("") || texto.trim().length==0
    }

    fun validarCamposIguales(texto:String,texto2: String):Boolean{
        return !texto.trim().equals(texto2.trim())
    }
    /**
     * VALIDA SI ES CORRECTO EL FORMATO DEL NOMBRE SEGUN UNA EXPRESION REGULAR
     */
    fun validarNombre(nombre:String):Boolean{
        val pattern = Pattern.compile("^[a-zA-Z ]+\$")
        return !pattern.matcher(nombre).matches()
    }
    /**
     * VALIDA SI ES CORRECTO EL FORMATO DEL CORREO SEGUN UNA EXPRESION REGULAR PREDETERMINADA
     */
    fun validarFormatoCorreo(correo:String):Boolean{
        return !Patterns.EMAIL_ADDRESS.matcher(correo).matches()
    }

}