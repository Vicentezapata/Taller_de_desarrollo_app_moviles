package roomDatabase.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import roomDatabase.entity.Cocktail

@Dao
interface DaoCocktail {
    @Query("SELECT * FROM Cocktail")
    //METODO PARA OBTENER LA INFO
    //suspend son las corrutinas estas son una de las características más impresionantes de Kotlin is simply a function that can be paused and resumed
    suspend fun obtenerCocktail(): List<Cocktail>

    @Query("SELECT * FROM Cocktail WHERE user=:user")
    suspend fun obtenerCoctelesUsuario(user: String): List<Cocktail>

    @Insert
    suspend fun agregarCocktail(cocktail: Cocktail):Long

    @Query("UPDATE  Cocktail SET name_cocktail=:name_cocktail,alcoholic_base=:alcoholic_base,recipe=:recipe,ingredients=:ingredients WHERE id=:id")
    suspend fun actualziarCocktail(name_cocktail:String,alcoholic_base: String,recipe:String,ingredients:String,id:Long): Int

    @Query("DELETE FROM Cocktail WHERE id=:id")
    suspend fun borrarCocktail(id: Long)
}