package com.example.recyclerviewexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.rv_datos)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val items = mutableListOf(
            Item("Elemento 1", "Descripción 1", R.drawable.ic_launcher_foreground),
            Item("Elemento 2", "Descripción 2", R.drawable.ic_launcher_foreground),
            Item("Elemento 3", "Descripción 3", R.drawable.ic_launcher_foreground)
            // Agrega más elementos según sea necesario
        )

        val adapter = CustomAdapter(items) { item ->
            Toast.makeText(this, "${item.title}, ${item.description}", Toast.LENGTH_SHORT).show()
        }
        recyclerView.adapter = adapter

    }
}