package com.example.recyclerviewexample

data class Item(val title: String, val description: String, val imageResId: Int)