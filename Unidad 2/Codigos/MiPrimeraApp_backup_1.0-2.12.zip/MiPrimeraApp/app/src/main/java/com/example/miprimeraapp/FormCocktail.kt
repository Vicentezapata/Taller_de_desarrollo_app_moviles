package com.example.miprimeraapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.textfield.TextInputLayout

class FormCocktail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_cocktail)
        //OBTENEMOS INTENT ANTERIOR
        //OBTENEMOS EL VALOR DEL INTENT
        val name_cocktail:String = intent.getStringExtra("name_cocktail").toString()


        //REFERENCIAS ID
        val til_name_cocktail = findViewById<TextInputLayout>(R.id.til_name_cocktail)
        val btn_edit = findViewById<Button>(R.id.btn_edit)
        val btn_delete = findViewById<Button>(R.id.btn_delete)


        //ASIGNAMOS VALOR AL TIL
        til_name_cocktail.editText?.setText(name_cocktail)

        btn_delete.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Confirmacion")
            builder.setMessage("¿Estas seguro de eliminar?")
            builder.setPositiveButton(android.R.string.ok){
                dialog, wich ->
                //ACCION A REALIZAR
                Toast.makeText(this,"Elemento eliminado",Toast.LENGTH_SHORT).show()
                val intent =Intent(this,DashboardUser::class.java)
                startActivity(intent)
            }
            builder.setNegativeButton("Cancelar",null)
            builder.setNeutralButton("No lo se",null)
            builder.show()
        }

    }
}