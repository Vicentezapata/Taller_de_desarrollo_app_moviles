package com.example.miprimeraapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class DashboardUser : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_user)
        //REFERENCIAS
        val tv_user = findViewById<TextView>(R.id.tv_user)
        val sp_category = findViewById<Spinner>(R.id.sp_category)
        val lv_datos = findViewById<ListView>(R.id.lv_datos)

        //OBTENEMOS EL VALOR DEL INTENT
        val mail:String = intent.getStringExtra("mail").toString()
        tv_user.setText("Bienvenido ${mail}!")


        //GENERACION DEL SPINNER
        val arrayAdapterSpinner: ArrayAdapter<*>
        val alcohol = arrayOf("Todos las opciones","Ron","Pisco","Tequila","Vodka")
        arrayAdapterSpinner = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,alcohol)
        sp_category.adapter = arrayAdapterSpinner


        ///GENERACION DE LISTVIEW
        //Siempre acepta un Array o una Lista como entrada.
        var arrayAdapterListView: ArrayAdapter<*>
        var cocteles = arrayOf("Tequila margarita","La cucaracha","Mojito","Moscow mule","Pisco sour","Amaretto sour","Ponche","Chupilca del diablo","Pihuinche","Serena sour","Piña colada","Bloody mojito","Hand Shandy")
        arrayAdapterListView = ArrayAdapter(this,android.R.layout.simple_list_item_1,cocteles)
        //arrayAdapterListView = ArrayAdapter(this,R.layout.list_item,cocteles)
        lv_datos.adapter = arrayAdapterListView
        lv_datos.onItemClickListener = object : AdapterView.OnItemClickListener{
            override fun onItemClick(p0: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //Toast.makeText(this@DashboardUser,"Seleccionaste ${cocteles[position]}",Toast.LENGTH_SHORT).show()
                val intent = Intent(this@DashboardUser,FormCocktail::class.java)
                intent.putExtra("name_cocktail","${cocteles[position]}")
                startActivity(intent)
            }
        }

        //SPINNER DINAMICO
        sp_category.onItemSelectedListener = object :AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, id: Long) {
                var input = sp_category.selectedItem.toString()
                println(input)
                when(input){
                    "Todos las opciones" ->cocteles = arrayOf("Tequila margarita","La cucaracha","Mojito","Moscow mule","Pisco sour","Amaretto sour","Ponche","Chupilca del diablo","Pihuinche","Serena sour","Piña colada","Bloody mojito","Hand Shandy")
                    "Ron" -> cocteles = arrayOf("Roncola","Cuba libre")
                    "Pisco" -> cocteles = arrayOf("Piscola","Pisco sour")
                    "Tequila" -> cocteles = arrayOf("Tequila margarita")
                    "Vodka" -> cocteles = arrayOf("Bloody Mary","Black Russian","White Russian")
                }
                arrayAdapterListView = ArrayAdapter(this@DashboardUser,android.R.layout.simple_list_item_1,cocteles)
                lv_datos.adapter = arrayAdapterListView
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }
    }
}