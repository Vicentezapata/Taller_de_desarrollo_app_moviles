package com.example.miprimeraapp

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //REFERENCIA DE WIDGETS
        val til_mail = findViewById<TextInputLayout>(R.id.til_mail)
        val til_pass = findViewById<TextInputLayout>(R.id.til_pass)
        val sw_remember = findViewById<Switch>(R.id.sw_remember)
        val btn_login = findViewById<Button>(R.id.btn_login)
        val btn_register = findViewById<Button>(R.id.btn_register)

        //SHARED PREFERENCES
        val preferencias = getSharedPreferences("datos",Context.MODE_PRIVATE)
        //SI RECORDAMOS EL VALOR LO VAMOS A SETEAR
        til_mail.editText?.setText(preferencias.getString("mail",""))


        btn_login.setOnClickListener{
            var mail = til_mail.editText?.text.toString()
            var pass = til_pass.editText?.text.toString()
            var isRemember = sw_remember.isChecked
            if (validarCampos()==0){
                val editor = preferencias.edit()
                if(isRemember){
                    editor.putString("mail",mail)
                    editor.commit()
                }
                else{
                    editor.putString("mail","")
                    editor.commit()
                }
                println("$mail $pass $isRemember")
                Toast.makeText(this,"$mail $pass $isRemember",Toast.LENGTH_SHORT).show()
                val intent = Intent(this@MainActivity,DashboardUser::class.java)
                intent.putExtra("mail",mail)
                startActivity(intent)
            }
        }
        btn_register.setOnClickListener {
            val intent = Intent(this@MainActivity,RegistroDeUsuario::class.java)
            startActivity(intent)
        }

    }
    fun validarCampos():Int{
        var contador:Int = 0
        val til_mail = findViewById<TextInputLayout>(R.id.til_mail)
        val til_pass = findViewById<TextInputLayout>(R.id.til_pass)
        var mail = til_mail.editText?.text.toString()
        var pass = til_pass.editText?.text.toString()
        val validate = Validate()
        if(validate.validarCampoNulo(mail)){
            til_mail.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            if(validate.validarFormatoCorreo(mail)){
                til_mail.error = "El correo no tiene el formato correcto"
                contador++
            }
            else{
                til_mail.error = ""
            }
        }
        if(validate.validarCampoNulo(pass)){
            til_pass.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            til_pass.error = ""
        }
        return contador
    }
    override fun onStart() {
        super.onStart()
        Log.i("CICLO_DE_VIDA","onStart()")
    }
    override fun onResume() {
        super.onResume()
        Log.i("CICLO_DE_VIDA","onResume()")
    }
    override fun onPause() {
        super.onPause()
        Log.i("CICLO_DE_VIDA","onPause()")
    }
    override fun onStop() {
        super.onStop()
        Log.i("CICLO_DE_VIDA","onStop()")
    }
    override fun onRestart(){
        super.onRestart()
        Log.i("CICLO_DE_VIDA","onRestart()")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.i("CICLO_DE_VIDA","onDestroy()")
    }

}
