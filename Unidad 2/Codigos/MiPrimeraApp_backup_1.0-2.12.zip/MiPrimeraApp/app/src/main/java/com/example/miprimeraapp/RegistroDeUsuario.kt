package com.example.miprimeraapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.Toast
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class RegistroDeUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_de_usuario)
        //REFERENCIA DE WIDGETS
        val til_dateb = findViewById<TextInputLayout>(R.id.til_dateb)
        val rg_type_user = findViewById<RadioGroup>(R.id.rg_type_user)
        val btn_re_register = findViewById<Button>(R.id.btn_re_register)

        val cal = Calendar.getInstance()

        //DATEPICKER
        val listenerFecha = DatePickerDialog.OnDateSetListener { datePicker, anyo, mes, dia ->
            til_dateb.editText?.setText("$dia/$mes/$anyo")
        }
        val listenerHora = TimePickerDialog.OnTimeSetListener { timePicker, hora, minuto ->
            til_dateb.editText?.setText("$hora:$minuto")
        }
        til_dateb.editText?.setOnClickListener {
            //TimePickerDialog(this,listenerHora,cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),false).show()
            DatePickerDialog(this,listenerFecha,cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        btn_re_register.setOnClickListener {
            if (validarCampos()==0){
                val radioButton = findViewById<RadioButton>(rg_type_user.checkedRadioButtonId)
                println("${radioButton.getText()}")
                Toast.makeText(this,"Usuario registrado correctamente", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@RegistroDeUsuario,MainActivity::class.java)
                startActivity(intent)
            }
        }

    }

    fun validarCampos():Int{
        var contador:Int = 0
        val til_re_mail = findViewById<TextInputLayout>(R.id.til_re_mail)
        val til_re_name = findViewById<TextInputLayout>(R.id.til_re_name)
        val til_re_pass = findViewById<TextInputLayout>(R.id.til_re_pass)
        val til_re_rpass = findViewById<TextInputLayout>(R.id.til_re_rpass)
        var mail = til_re_mail.editText?.text.toString()
        var name = til_re_name.editText?.text.toString()
        var pass = til_re_pass.editText?.text.toString()
        var rpass = til_re_rpass.editText?.text.toString()
        val validate = Validate()
        if(validate.validarCampoNulo(mail)){
            til_re_mail.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            if(validate.validarFormatoCorreo(mail)){
                til_re_mail.error = "El correo no tiene el formato correcto"
                contador++
            }
            else{
                til_re_mail.error = ""
            }
        }
        if(validate.validarCampoNulo(pass)){
            til_re_pass.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            til_re_pass.error = ""
        }
        if(validate.validarCampoNulo(name)){
            til_re_name.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            if(validate.validarCamposIguales(pass,rpass)){
                til_re_pass.error = "Las contraseñas deben ser iguales"
                til_re_rpass.error = "Las contraseñas deben ser iguales"
                contador++
            }
            else{
                til_re_pass.error = ""
                til_re_rpass.error = ""
            }

        }
        if(validate.validarCampoNulo(rpass)){
            til_re_rpass.error = getString(R.string.error_null_field)
            contador++
        }
        else{
            if(validate.validarCamposIguales(pass,rpass)){
                til_re_pass.error = "Las contraseñas deben ser iguales"
                til_re_rpass.error = "Las contraseñas deben ser iguales"
                contador++
            }
            else{
                til_re_pass.error = ""
                til_re_rpass.error = ""
            }
        }

        return contador
    }
}