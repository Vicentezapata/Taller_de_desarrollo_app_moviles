package com.example.miprimeraapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegistroDeUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_de_usuario)
    }
}